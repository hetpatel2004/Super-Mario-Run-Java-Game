package Bonus;

import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.ImageIcon;

import Common.gameConstants;
import Music.BackGroundMusic;
import Player.Mplayer;

public class Coins {public static boolean isCoin;
     public static int I,X;
	 boolean isUp;
	 int ySpeed,H,W,Y;
     Image image;
     // default constructor
     public Coins(){
    	 
     }
     // to initiate coins size
	 public Coins(int y ,int w,int h){
		 image= new ImageIcon(Mplayer.class.getResource("coins.gif")).getImage();
		    
			this.Y=y;
			this.H=h;
			this.W=w;	
			
			up();
	 }	

    //to draw image
	public  void check(Graphics2D g){		
		
		g.drawImage(image,X,Y,W,H,null);
	
		
	}
	// to make coin jump accordingly in gameplay
	public void up() {
		if(!isUp){
			ySpeed=-13;
			Y+=ySpeed;
			isUp=true;
		}}
	
	// to make coin fall and add as points accordingly to the gameplay
	
	public void fall(){int temp;
	if(I<8)
		temp=gameConstants.COIN_FIRST_FLOOR_MAX;
	else
		temp=gameConstants.COIN_SECOND_FLOOR_MAX;
			if(Y>temp){	
				ySpeed+=1;
				Y+=ySpeed;
				if(Y<=temp)
				{	
					Coins.isCoin=false; 
				BonusItems.isTaken[I]=true;//for making the coin invisible
				}
				
			
			}
			else if(Y<=temp){
				isUp=false;
				
			}
			
		}

		
	

}
