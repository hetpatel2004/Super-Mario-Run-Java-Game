package Bonus;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.Timer;

import Common.gameConstants;
import Player.Mplayer;
import game.Camera;

abstract public class Rocket {
	String name="rocket.png";
	//image object for rocket initialized
	Image image= new ImageIcon(Mplayer.class.getResource(name)).getImage();
	public abstract void check(Graphics2D g);
	//rocket on collision action
	public void actionOnCollision(){

	}
}
