package Bonus;

//interface for Skates image
public interface Skates {
	String name="skates.png";
	public boolean check();

}
