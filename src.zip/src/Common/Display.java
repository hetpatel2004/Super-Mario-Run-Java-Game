package Common;

// global classes declared to count all types of points, accordingly to the gameplay
public class Display {
	public static float TIME=200;
    public static int SCORE=0;
    public static int COINS=0;
    public static int FLY;
    public static int FIRE;
    public static int FLOWER;
    public static int STAR;
}
