package Common;

//to globally declare constant values
public interface gameConstants {
	int GWIDTH=1100;
	int GHEIGHT=705;
  
    int CAMERA_SPEED=4;
   
   int DELAY=50;
   
    int IMAGE_HEIGHT=GHEIGHT/3;
    int IMAGE_WIDTH=GWIDTH/3;
    int MARIO_SIZE=100;
    int MARIO_X=100;
    int GRAVITY=3;
    int GROUND_FLOOR=468;
    int FIRST_FLOOR=368;
    int SECOND_FLOOR=178; 
    int COIN_FIRST_FLOOR_MAX=238;
    int COIN_SECOND_FLOOR_MAX=48;
    int InPipeGroundFloor=536;
    int InPipePipeFloor=436;
    int InPipeBrickFloor=380;
 

}
