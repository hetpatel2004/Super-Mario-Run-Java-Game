package Draw;

import Obstacles.Collision;
import Player.Mplayer;

//brick collision up down handled
public class actionOnCollision {
	Collision collision =new Collision();
	
	public void setFloor(int floor){
		Mplayer.FLOOR=floor;
	}
	public void downCollisionBrick(){
		
	}
	public void downCollisionQuestM(){
		
	}

}
