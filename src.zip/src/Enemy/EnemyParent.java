package Enemy;

import java.awt.Image;

import Common.gameConstants;
import Music.BackGroundMusic;
import Player.Mplayer;



public abstract class EnemyParent {
	int x;
	int y;
	int ySpeed;
	int width;
	int height;
	int speed;
	int speedOwn;
	int floor;
	int identifier;
	boolean die;
	int boundary1,boundary2;
	String imageName;
	Image img;
	

public void move(){
	;
	boundary1+=speed;
	boundary2+=speed;
	x+=speed;
}
public void moveOwn(){
	x+=speedOwn;
}

//method to tack collision with enemies
public int checkCollision(int marioX,int marioY,int goombaX,int goombaY){
	int value=0;
	if(Math.abs(marioX-goombaX)<=49&&Math.abs(marioY-goombaY)<=60&&Mplayer.ySpeed>0&&(Mplayer.ySpeed<37||Mplayer.ySpeed>48)&&Mplayer.ySpeed>=33){
    value=1;
  
    }
	else if(marioY<=goombaY)
	{   
		if(Math.abs(marioY-goombaY)<50 && Math.abs(marioX-goombaX)<=50)
		{  if(!Mplayer.isStar)
			{
			value=2;}
		else {
			value=3;
			
			
		}
	
		}
	}
	else{
		if(Math.abs(marioY-goombaY)<=10&& Math.abs(marioX-goombaX)<=50)
			{if(!Mplayer.isStar)
				value=2;
			else {value=3;
			
		
			}
		
			}
		
	}
   
	return value;
}



}
