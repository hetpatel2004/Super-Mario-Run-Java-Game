package Enemy;

public class KroopaTroopa extends EnemyParent{

}
