package Music;

import java.io.File;

import Player.Mplayer;

public class BackGroundMusic {
	
//		public static MP3Player mp31 =new MP3Player(new File("Theme-Ringtone.mp3"));
//		
//		
//	public static void playSuperJump(){
//		MP3Player mp32 =new MP3Player(new File("smb_jump-super.mp3"));
//		mp32.play();}
//	public static void playMarioDie(){
//		MP3Player mp32 =new MP3Player(new File("smb_mariodie.mp3"));
//		mp32.play();}
//	public static void playBrickBreak(){
//		MP3Player mp32 =new MP3Player(new File("smb_breakblock.mp3"));
//		mp32.play();
//	}
//    public static void playAfterBonus (){
//    	MP3Player mp32 =new MP3Player(new File("smb_bump.mp3"));
//		mp32.play();
//	}
//    public static void playCoin (){
//    	MP3Player mp32 =new MP3Player(new File("smb_coin.mp3"));
//		mp32.play();
//    }
//    public static void playBonusTaken(){
//    	MP3Player mp32 =new MP3Player(new File("smb_powerup.mp3"));
//		mp32.play();
//    }
//    public static void playBonusAppear(){
//    	MP3Player mp32 =new MP3Player(new File("smb_powerup_appears.mp3"));
//		mp32.play();
//    }
//    public static void playEnemyDie(){
//    	MP3Player mp32 =new MP3Player(new File("smb_stomp.mp3"));
//		mp32.play();
//    }
//    public static void playMarioFire(){
//    	MP3Player mp32 =new MP3Player(new File("smb_fireball.mp3"));
//		mp32.play();
//    }
//    public static void playFlagPole(){
//    	MP3Player mp32 =new MP3Player(new File("smb_flagpole.mp3"));
//		mp32.play();
//    }
//    public static void playLevelComplete(){
//    	MP3Player mp32 =new MP3Player(new File("smb_world_clear.mp3"));
//		mp32.play();
//    }
//    public static void playPipe(){
//    	MP3Player mp32 =new MP3Player(new File("smb_pipe.mp3"));
//		mp32.play();
//    }
}
