package Obstacles;



public class Collision {
	private boolean isCollision;
pipes pipe=new pipes();
Stairs stairs=new Stairs();
//collision handled here
public boolean isCollision(int x){
	if(pipe.checkPipeCollision(x)||stairs.checkStairCollision(x))
		isCollision=true;
	else isCollision=false;
	return isCollision;
}
}
