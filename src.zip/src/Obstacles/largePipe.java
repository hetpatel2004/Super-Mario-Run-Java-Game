package Obstacles;

//interface for pipes initialized

public interface largePipe {
	int width=48;
    int floor=274;
    public boolean check();
}
