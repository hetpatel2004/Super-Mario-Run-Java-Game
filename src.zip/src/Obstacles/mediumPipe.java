package Obstacles;

public interface mediumPipe {
	int width=48;
    int floor=321;
    public boolean check();
}
