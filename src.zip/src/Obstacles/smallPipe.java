package Obstacles;

public interface smallPipe {
	int width=48;
    int floor=371;
    public boolean check();
}
