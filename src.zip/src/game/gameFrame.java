package game;

import java.awt.*;

import javax.swing.*;

import Common.gameConstants;
import static Common.gameConstants.GHEIGHT;
import static Common.gameConstants.GWIDTH;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class gameFrame extends JFrame implements gameConstants{
    JButton b1;
    JButton b2;
 JLabel lb1;
 
	public gameFrame() {
		

                 lb1 = new JLabel("Mario Game");
        lb1.setFont(new Font("Verdana", Font.PLAIN, 30));
        lb1.setBounds(60, 20, 300, 40);
        b1 = new JButton("Start");
        b1.setBounds(75, 100, 150, 30);
     
        b1.setFont(new Font("Tahoma", Font.BOLD, 20));
        b2 = new JButton("Exit");
        b2.setBounds(75, 150 , 150, 30);
        b2.setFont(new Font("Tahoma", Font.BOLD, 20));
        JFrame menu = new JFrame();
        JPanel panel = new JPanel();

        panel.setLayout(new GridLayout(3, 10));
        panel.setSize(new Dimension(300, 200));

        panel.setLocation((menu.getWidth() - panel.getWidth()) / 2, 0); // 0 is just the Y location
        menu.setSize(new Dimension(300, 300));
        menu.add(b1);
        menu.add(b2);
        menu.add(lb1);

        menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menu.setLayout(null);
        menu.setLocation(250, 100);
        menu.setVisible(true);
        menu.setSize(300, 350);

   b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menu.dispose();
              // TODO Auto-generated method stub
              setTitle("Super Mario By Het");
		setVisible(true);
		setSize(GWIDTH, GHEIGHT);
		setLocationRelativeTo(null);
		setResizable(false);
        
     Toolkit.getDefaultToolkit().sync();
    
          LoadBoard();
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                menu.dispose();

            }
        });
                
	}
	public void LoadBoard()
	{
		Board board=new Board();
		this.add(board);
		board.bindEvent();
	}

	public static void main(String[] args) {
	
	  gameFrame game=new gameFrame();
      Toolkit.getDefaultToolkit().sync();	
       
	}

}
